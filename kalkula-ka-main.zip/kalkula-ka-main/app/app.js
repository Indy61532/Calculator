const http = require("http");
const fs = require("fs");

const html = fs.readFileSync("../index.html");
const css = fs.readFileSync("../style.css");
const js = fs.readFileSync("../functions.js");

const server = http.createServer(function(req, res){
    if(req.url == "/"){
        res.writeHead(200, {"Content-Type": "text/html"});
        res.write(html); 
    }else if(req.url == "/style.css"){
        res.writeHead(200, {"Content-Type": "text/css"});
        res.write(css); 
    }else if(req.url == "/functions.js"){
        res.writeHead(200, {"Content-Type": "application/javascript"});
        res.write(js);
    }else{
        res.writeHead(404, {"Content-Type": "text/plain"});
        res.write("ERROR 404 PAGE NOT FOUND");
    }
    res.end();
});

server.listen(3000, () => {
    console.log("Server running on port 3000");
});
